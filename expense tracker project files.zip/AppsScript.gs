/**
 * HOUSEHOLD EXPENSE TRACKER — Google Apps Script backend
 *
 * SETUP:
 * 1. Open your Google Sheet (Household Expense Tracker).
 * 2. Extensions > Apps Script.
 * 3. Delete any starter code, paste this whole file in.
 * 4. Save, then Run > setup (creates the Expenses + Budgets tabs).
 *    Authorize when prompted.
 * 5. Deploy > New deployment > Web app.
 *    - Execute as: Me
 *    - Who has access: Anyone with the link
 * 6. Copy the Web App URL into the dashboard's config.js as API_URL.
 *
 * If you're updating an EXISTING deployment with this new version,
 * you still need: Deploy > Manage deployments > pencil icon >
 * "New version" > Deploy. Just saving the code is not enough.
 */

const SHEET_NAME = 'Expenses';
const BUDGETS_SHEET_NAME = 'Budgets';

const EXPENSE_HEADERS = ['Timestamp', 'Date', 'Category', 'Amount', 'Notes', 'LoggedBy'];
const BUDGET_HEADERS = ['Category', 'MonthlyLimit'];

const CATEGORIES = [
  'Utilities', 'Groceries', 'Dining Out', 'Transportation',
  'Baby & Childcare', 'Healthcare', 'Household Supplies',
  'Personal Care', 'Entertainment & Subscriptions', 'Other'
];

function setup() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();

  let sheet = ss.getSheetByName(SHEET_NAME);
  if (!sheet) sheet = ss.insertSheet(SHEET_NAME);
  if (sheet.getLastRow() === 0) {
    sheet.appendRow(EXPENSE_HEADERS);
    sheet.getRange(1, 1, 1, EXPENSE_HEADERS.length).setFontWeight('bold');
  }

  let budgetSheet = ss.getSheetByName(BUDGETS_SHEET_NAME);
  if (!budgetSheet) budgetSheet = ss.insertSheet(BUDGETS_SHEET_NAME);
  if (budgetSheet.getLastRow() === 0) {
    budgetSheet.appendRow(BUDGET_HEADERS);
    budgetSheet.getRange(1, 1, 1, BUDGET_HEADERS.length).setFontWeight('bold');
    // Pre-fill every category with an empty (no limit) row so it's easy to fill in later
    CATEGORIES.forEach(cat => budgetSheet.appendRow([cat, '']));
  }

  const def = ss.getSheetByName('Sheet1');
  if (def && def.getLastRow() === 0) ss.deleteSheet(def);
}

function doGet(e) {
  const action = (e.parameter.action || 'summary');
  let result;
  try {
    if (action === 'summary') {
      result = getSummary(e.parameter.month, e.parameter.year);
    } else if (action === 'logs') {
      result = getRecentLogs(parseInt(e.parameter.limit || '15', 10));
    } else if (action === 'history') {
      result = getHistory(e.parameter.start, e.parameter.end);
    } else if (action === 'filter') {
      result = getFiltered(e.parameter.category, e.parameter.keyword, e.parameter.start, e.parameter.end);
    } else if (action === 'trend') {
      result = getTrend(parseInt(e.parameter.months || '6', 10));
    } else if (action === 'budgets') {
      result = getBudgets();
    } else {
      result = { error: 'Unknown action' };
    }
  } catch (err) {
    result = { error: err.message };
  }
  return ContentService.createTextOutput(JSON.stringify(result))
    .setMimeType(ContentService.MimeType.JSON);
}

function doPost(e) {
  let result;
  try {
    const body = JSON.parse(e.postData.contents);
    const ss = SpreadsheetApp.getActiveSpreadsheet();

    if (body.type === 'set_budget') {
      result = setBudget(body.category, body.limit);
    } else {
      // default: log an expense
      const sheet = ss.getSheetByName(SHEET_NAME);
      const now = new Date();
      const expenseDate = body.date ? new Date(body.date + 'T00:00:00') : now;

      sheet.appendRow([
        now,
        expenseDate,
        body.category || '',
        Number(body.amount) || 0,
        body.notes || '',
        body.loggedBy || ''
      ]);
      result = { ok: true };
    }
  } catch (err) {
    result = { ok: false, error: err.message };
  }
  return ContentService.createTextOutput(JSON.stringify(result))
    .setMimeType(ContentService.MimeType.JSON);
}

/** Reads the Budgets tab into { category: limit } */
function readBudgetMap() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  const sheet = ss.getSheetByName(BUDGETS_SHEET_NAME);
  if (!sheet) return {};
  const data = sheet.getDataRange().getValues().slice(1);
  const map = {};
  data.forEach(r => {
    if (r[0] && r[1] !== '' && r[1] !== null) map[r[0]] = Number(r[1]);
  });
  return map;
}

function getBudgets() {
  const map = readBudgetMap();
  return {
    budgets: CATEGORIES.map(cat => ({ category: cat, limit: map[cat] || null }))
  };
}

function setBudget(category, limit) {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  const sheet = ss.getSheetByName(BUDGETS_SHEET_NAME);
  const data = sheet.getDataRange().getValues();
  for (let r = 1; r < data.length; r++) {
    if (data[r][0] === category) {
      sheet.getRange(r + 1, 2).setValue(limit === '' || limit === null ? '' : Number(limit));
      return { ok: true };
    }
  }
  // category not found, add it
  sheet.appendRow([category, limit === '' ? '' : Number(limit)]);
  return { ok: true };
}

/** Given month/year (1-indexed month, optional — defaults to current), returns totals + budget status */
function getSummary(monthParam, yearParam) {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  const sheet = ss.getSheetByName(SHEET_NAME);
  const now = new Date();

  const year = yearParam ? parseInt(yearParam, 10) : now.getFullYear();
  const month = monthParam ? parseInt(monthParam, 10) - 1 : now.getMonth(); // JS months are 0-indexed
  const monthStart = new Date(year, month, 1);
  const monthEnd = new Date(year, month + 1, 0, 23, 59, 59);

  const data = sheet.getDataRange().getValues().slice(1).filter(r => r[0]);
  const inMonth = data.filter(r => {
    const d = new Date(r[1]);
    return d >= monthStart && d <= monthEnd;
  });

  const byCategory = {};
  CATEGORIES.forEach(c => byCategory[c] = 0);
  let total = 0;
  inMonth.forEach(r => {
    const cat = r[2] || 'Other';
    const amt = Number(r[3]) || 0;
    byCategory[cat] = (byCategory[cat] || 0) + amt;
    total += amt;
  });

  const budgetMap = readBudgetMap();

  const categoryBreakdown = Object.keys(byCategory)
    .map(cat => {
      const limit = budgetMap[cat] || null;
      const amount = byCategory[cat];
      let status = 'ok';
      if (limit) {
        const pct = amount / limit;
        if (pct >= 1) status = 'over';
        else if (pct >= 0.8) status = 'warning';
      }
      return { category: cat, amount: amount, limit: limit, status: status };
    })
    .filter(c => c.amount > 0)
    .sort((a, b) => b.amount - a.amount);

  return {
    monthTotal: total,
    monthLabel: Utilities.formatDate(monthStart, Session.getScriptTimeZone(), 'MMMM yyyy'),
    month: month + 1,
    year: year,
    categoryBreakdown: categoryBreakdown,
    entryCount: inMonth.length,
    serverTime: now
  };
}

/** Most recent N expense entries */
function getRecentLogs(limit) {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  const sheet = ss.getSheetByName(SHEET_NAME);
  const data = sheet.getDataRange().getValues().slice(1).filter(r => r[0]);

  const events = data.map(r => ({
    timestamp: r[0],
    date: r[1],
    category: r[2],
    amount: Number(r[3]) || 0,
    notes: r[4],
    loggedBy: r[5]
  }));

  events.sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp));
  return { events: events.slice(0, limit) };
}

/** Totals + full list for a custom date range (inclusive) */
function getHistory(startStr, endStr) {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  const sheet = ss.getSheetByName(SHEET_NAME);

  const start = startStr ? new Date(startStr + 'T00:00:00') : new Date(0);
  const end = endStr ? new Date(endStr + 'T23:59:59') : new Date();

  const data = sheet.getDataRange().getValues().slice(1).filter(r => r[0]);
  const inRange = data.filter(r => {
    const d = new Date(r[1]);
    return d >= start && d <= end;
  });

  const byCategory = {};
  let total = 0;
  inRange.forEach(r => {
    const cat = r[2] || 'Other';
    const amt = Number(r[3]) || 0;
    byCategory[cat] = (byCategory[cat] || 0) + amt;
    total += amt;
  });

  const categoryBreakdown = Object.keys(byCategory)
    .map(cat => ({ category: cat, amount: byCategory[cat] }))
    .sort((a, b) => b.amount - a.amount);

  const events = inRange.map(r => ({
    timestamp: r[0], date: r[1], category: r[2],
    amount: Number(r[3]) || 0, notes: r[4], loggedBy: r[5]
  })).sort((a, b) => new Date(b.date) - new Date(a.date));

  return {
    range: { start: startStr, end: endStr },
    total: total,
    categoryBreakdown: categoryBreakdown,
    events: events
  };
}

/** Filter by category AND/OR keyword (in Notes), within an optional date range */
function getFiltered(category, keyword, startStr, endStr) {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  const sheet = ss.getSheetByName(SHEET_NAME);

  const start = startStr ? new Date(startStr + 'T00:00:00') : new Date(0);
  const end = endStr ? new Date(endStr + 'T23:59:59') : new Date();
  const kw = (keyword || '').toLowerCase().trim();
  const cat = (category || '').trim();

  const data = sheet.getDataRange().getValues().slice(1).filter(r => r[0]);
  const matched = data.filter(r => {
    const d = new Date(r[1]);
    if (d < start || d > end) return false;
    if (cat && cat !== 'All categories' && r[2] !== cat) return false;
    if (kw && !(String(r[4] || '').toLowerCase().includes(kw))) return false;
    return true;
  });

  let total = 0;
  const events = matched.map(r => {
    total += Number(r[3]) || 0;
    return {
      timestamp: r[0], date: r[1], category: r[2],
      amount: Number(r[3]) || 0, notes: r[4], loggedBy: r[5]
    };
  }).sort((a, b) => new Date(b.date) - new Date(a.date));

  return {
    total: total,
    entryCount: events.length,
    events: events
  };
}

/** Last N months of totals, oldest first — for the trend chart */
function getTrend(numMonths) {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  const sheet = ss.getSheetByName(SHEET_NAME);
  const data = sheet.getDataRange().getValues().slice(1).filter(r => r[0]);
  const now = new Date();

  const months = [];
  for (let i = numMonths - 1; i >= 0; i--) {
    const d = new Date(now.getFullYear(), now.getMonth() - i, 1);
    months.push({ year: d.getFullYear(), month: d.getMonth(), label: Utilities.formatDate(d, Session.getScriptTimeZone(), 'MMM') });
  }

  const totals = months.map(m => {
    const start = new Date(m.year, m.month, 1);
    const end = new Date(m.year, m.month + 1, 0, 23, 59, 59);
    const sum = data
      .filter(r => { const d = new Date(r[1]); return d >= start && d <= end; })
      .reduce((s, r) => s + (Number(r[3]) || 0), 0);
    return { label: m.label, year: m.year, month: m.month + 1, total: sum };
  });

  return { months: totals };
}
