# Household Expense Tracker — Setup Guide

Same proven stack as the baby tracker: **Google Sheet** (database) +
**Google Apps Script** (free API) + **Vercel** (hosting). Since you
want this under your **personal Gmail** from the start, Step 1 is
making your own copy.

## Step 1 — Create your Sheet on your personal Google account
1. Log into your **personal Gmail** in your browser.
2. Go to [sheets.google.com](https://sheets.google.com) and create a
   **new blank spreadsheet**.
3. Rename it (e.g. "Household Expense Tracker") — click the title
   top-left.
4. You don't need to add any headers manually — the script in
   Step 2 creates everything automatically.

## Step 2 — Add the backend script
1. In your new Sheet, **Extensions > Apps Script**.
2. Delete the placeholder code (`function myFunction() {}`).
3. Paste in the full contents of `AppsScript.gs` (provided below).
4. Click **Save** (💾 icon).
5. In the function dropdown at the top, select **setup**, then click
   **Run** (▶️).
   - First time, it'll ask to authorize — click **Review
     permissions** > choose your personal account > **Advanced** >
     "Go to [project name] (unsafe)" > **Allow**. This is normal for
     your own scripts.
6. This creates two tabs: **Expenses** (your expense log) and
   **Budgets** (monthly limits per category, pre-filled with all 10
   categories and blank limits).

## Step 3 — Deploy as a Web App
1. **Deploy** (top right) > **New deployment**.
2. Click the gear icon ⚙️ next to "Select type" > **Web app**.
3. Settings:
   - **Execute as:** Me
   - **Who has access:** Anyone with the link
4. Click **Deploy**, authorize again if asked.
5. Copy the **Web app URL** (starts with
   `https://script.google.com/macros/s/...`).

## Step 4 — Point the dashboard at your Sheet
1. Open `config.js`.
2. Replace the placeholder with your Web App URL:
   ```js
   const API_URL = "https://script.google.com/macros/s/AKfycb.../exec";
   ```

## Step 5 — Deploy to Vercel
1. Go to [github.com](https://github.com), create a new repository
   (e.g. `expense-tracker`).
2. **Add file > Upload files**, drag in: `index.html`, `app.js`,
   `config.js`, `manifest.json`, `vercel.json`. Commit changes.
3. Go to [vercel.com](https://vercel.com) — **make sure you're
   logged in with your personal email**, same as the baby tracker.
4. **Add New... > Project**, find `expense-tracker` in the list,
   click **Import**.
   - If it's not listed, click "Continue with GitHub" first to
     connect/authorize, or check "Adjust GitHub App Permissions" to
     grant access to the repo.
5. Leave settings as default, click **Deploy**.
6. Once done, open the live URL (e.g.
   `https://expense-tracker-xyz.vercel.app`), and on your phone use
   **Share > Add to Home Screen**.

## Step 6 — Load the dummy test data (optional, for trying it out)
1. Open `dummy_expenses.csv`.
2. Select all 300 data rows (everything except the header row) and
   copy.
3. In your Sheet's **Expenses** tab, click cell **A2**, paste.
4. Check that columns A (Timestamp) and B (Date) show as real dates
   (right-aligned), not text (left-aligned). If they're left-aligned,
   select those columns and apply **Format > Number > Date time** /
   **Date**.
5. Reload your dashboard — you should see live totals, category
   breakdowns, and a populated 6-month trend chart.

To remove the test data later: select rows 2–301 in the Expenses
tab, right-click, **Delete rows**.

## Step 7 — Set budget limits (optional)
1. On the dashboard, tap the **⚙️ Budgets** button in the header.
2. Enter a monthly limit for any category you want to track (leave
   blank for no limit). Amounts auto-format as you type.
3. Tap **Save**. Category bars will now show amber (80%+ used) or
   red (over budget) automatically each month.

## Features in this version
- **Month picker** — ‹ › arrows in the header to browse any month
- **Budget limits** — per-category monthly caps with visual warnings
- **6-month trend chart** — quick view of spending direction over time
- **Filter** — by category, keyword (searches Notes), and date range
  (8 quick presets or custom dates)
- **Currency-aware input** — amounts auto-format with thousands
  separators as you type

## Categories used
Utilities, Groceries, Dining Out, Transportation, Baby & Childcare,
Healthcare, Household Supplies, Personal Care, Entertainment &
Subscriptions, Other.

To change these later: edit the `CATEGORIES` list in
`AppsScript.gs`, the pill options in `index.html`'s
`expCategoryRow`, and the `<option>` list in `filterCategory`. Then
redeploy both — Apps Script needs **Deploy > Manage deployments >
pencil ✏️ > New version > Deploy** (saving alone isn't enough), and
the dashboard just needs re-upload to GitHub (Vercel auto-redeploys).
